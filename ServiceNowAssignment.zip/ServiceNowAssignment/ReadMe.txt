I have used Maven project to answer all my questions. Attached the pom.xml in the zip file attached

Please place chromedriver.exe in this location ServiceNowAssignment/src/test/resources
Excel Path: src/test/resources/ searchKeywords.xlsx
Screenshot Path: src/test/resources/screenshots

Below is the framework structure created for JAVA files: 

Page Object Java Files Path: 
Folder structure : src/test/java
Package Name : com.pageObjects
Java Files created: AllMovies_PageFactory_Page2.java


Test Scripts Java Files Path: 
Folder structure : src/test/java
Package Name : com.testScripts
Java Files created: Question2.java, Question3_TestNG.xml

Reusable Classes and Constants File:
Folder structure : src/main/java
Package Name : com.testing.base
Files created: TestBase.java
Package Name: com.testing.util
Files created: Constants.java, ExtentManager.java, FileFilterDateIntervalUtils.java

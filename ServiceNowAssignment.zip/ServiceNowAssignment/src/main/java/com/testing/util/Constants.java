package src.main.java.com.testing.util;

public class Constants {
	
	public static final String ENV="SIT";
	
	//URL's
	public static final String amazonUrl="https://www.amazon.in";
	public static final String gmailUrl="https://gmail.com";
	public static final String uploadFileUrl="http://demo.guru99.com/selenium/upload/";
	
	//Extent Report Path
	public static final String REPORT_PATH="src\\test\\resources\\";
	
	public static final String CHROME_DRIVER_EXE="src\\test\\resources\\chromedriver.exe";
	public static final String FIREFOX_DRIVER_EXE="src\\\\test\\resources\\geckodriver.exe";
	public static final String IE_DRIVER_EXE="src\\test\\resources\\iedriver.exe";

	//wordpress excel file path
	public static final String ExcelTest_XLS="src\\test\\resources\\ExcelTest.xlsx";	
	
	/**
	 * Sales Force
	 */
	public static final String URL="https://www.salesforce.com/in/form/signup/freetrial-sales.jsp?d=70130000000EgEv";
	//public static final String firstNm="//input[@id=\"UserFirstName\"]";
	
	public static final String FirstName="//input[@name=\"UserFirstName\"]";
	
	//public static final String lastNm="//input[@id='UserLastName']";
	public static final String LastName="//input[@placeholder='Last name']";
	
	//Multiple attributes
	//public static final String email="//input[@id='UserEmail]";
	public static final String Email="//input[@id='UserEmail' and @name='UserEmail']";
	
	public static final String Phone="//input[@id=\"UserPhone\"]";
	public static final String CompanyName="//*[@id=\"CompanyName\"]";
	
	public static final String LastName_Id="UserLastName";
	public static final String LastName_Name="UserLastName";
	
	public static final String JobTitle="//*[@id=\"form-container\"]/ul/li[3]/div/div[2]/a/span[1]";
	public static final String Employees="//*[@id=\"form-container\"]/ul/li[7]/div/div[2]/a/span[1]";	
	public static final String Country="//*[@id=\"form-container\"]/ul/li[8]/div/div[2]/a/span[1]";	
	public static final String State="//*[@id=\"form-container\"]/ul/li[9]/div/div[2]/a/span[1]";
	//*[@id="form-container"]/ul/li[9]/div/div[2]/a
	public static final String Agreement="//*[@id=\"SubscriptionAgreement\"]";
	public static final String StartFreeTrial="//*[@id=\"form-container\"]/div[2]/div/a";
	
	/**
	 * Alert properties
	 */
	public static final String alertsUrl="http://test1.absofttrainings.com/javascript-alert-confirm-prompt-boxes/";

}

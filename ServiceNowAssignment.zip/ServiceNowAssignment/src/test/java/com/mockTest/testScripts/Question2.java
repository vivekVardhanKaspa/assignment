package src.test.java.com.mockTest.testScripts;


import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

//import com.pageObjects.AllMovies_PageFactoryPage1;
import src.test.java.com.pageObjects.AllMovies_PageFactory_Page2;
import src.main.java.com.testing.base.TestBase;
/*Question 2: 6.Using Page Object Model, TestNG and WebDriver script, open ‘https://www.allmovie.com/’ in Chrome and do the below: (14 points)
a.Click on Advanced Search
b.Select first 3 checkboxes under Genres & SubGenres
c.Check all 3 filters are present under Advanced Movie Search
d.Print all the movie Title from the current page
e.Go back on the home page by browser back button
f.Assert the page title with “AllMovie | Movies and Films Database | Movie Search, Ratings, Photos, Recommendations, and Reviews””.*/

public class Question2 extends TestBase{
	WebDriverWait wait;
	Actions builder; 
	@BeforeTest
	public void beforeTest() {
		System.out.println("Before test begins");
		logger=extent.createTest("Question 2 Test");
		init("Chrome");
		d.get("http://automationpractice.com/");
		wait=new WebDriverWait(d, 30);
		builder = new Actions(d);
	}
	@Test
	public void question1() {
		try {
			System.out.println("========================================");
			//AllMovies_PageFactoryPage1 obj = new AllMovies_PageFactoryPage1(d);
			AllMovies_PageFactory_Page2 obj1 = new AllMovies_PageFactory_Page2(d);
			String fileName="src\\test\\resources\\searchKeywords.xlsx";
			String sheetName="Sheet1";
				String data=readData(fileName, sheetName, 0, 0);
				String userName=readData(fileName, sheetName, 1, 0);
				String passWord=readData(fileName, sheetName, 2, 0);
				System.out.println("Entry Criteria "+data);
				obj1.enterBasicSearchCriteria(obj1.topSearch, data);
				Thread.sleep(1000);
			wait.until(ExpectedConditions.visibilityOf(obj1.searchCheck));
			takeScreenShot("SearchedText.png");
			obj1.sortBy.click();
			obj1.lowestFirst.click();
			wait.until(ExpectedConditions.visibilityOf(obj1.firstHover));
			builder.moveToElement(obj1.firstHover).click(obj1.addToCartFirstLink).build().perform();
			wait.until(ExpectedConditions.visibilityOf(obj1.checkoutLink));
			takeScreenShot("sucessfullyAddedToCart.png");
			obj1.checkoutLink.click();
			//scrollIntoView(obj1.checkoutSecondLink);
			wait.until(ExpectedConditions.visibilityOf(obj1.checkoutSecondLink));
			takeScreenShot("fistStepInFlow.png");
			jsClick(obj1.checkoutSecondLink);
			wait.until(ExpectedConditions.visibilityOf(obj1.emailField));
			obj1.emailField.sendKeys(userName);
			obj1.pswdField.sendKeys(passWord);
			takeScreenShot("signInFlow.png");
			obj1.loginSubmit.click();
			wait.until(ExpectedConditions.visibilityOf(obj1.checkoutButton));
			takeScreenShot("addressInFlow.png");
			obj1.checkoutButton.click();
			//wait.until(ExpectedConditions.visibilityOf(obj1.checkBoxTC));
			jsClick(obj1.checkBoxTC);
			takeScreenShot("clickOnCheckBox.png");
			obj1.checkoutButton.click();
			wait.until(ExpectedConditions.visibilityOf(obj1.payByCheck));
			takeScreenShot("payByCheck.png");
			obj1.payByCheck.click();
			wait.until(ExpectedConditions.visibilityOf(obj1.confirmMyOrder));
			takeScreenShot("confirmMyOrder.png");
			obj1.confirmMyOrder.click();
			takeScreenShot("confirmationMessage.png");
			scrollIntoView(obj1.confirmationMessage);
			//Assert Page title
			Assert.assertEquals(obj1.confirmationMessage.getText(),
					"Your order on My Store is complete.",
					"Order is complete");
			System.out.println("Assert Pass");
			
		}
		catch(Exception e) {
			System.out.println("Error: "+e.getMessage());
			log("Test Case failed");
			d.close();
			log("Application closed");
		}
	}
	@AfterTest
	public void afterTest() {
		if (extent!=null) {
			extent.flush();
		}
		if (d!=null) {
			terminate();
		}
	}
	}

package src.main.java.com.testing.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import src.main.java.com.testing.util.Constants;
import src.main.java.com.testing.util.ExtentManager;
public class TestBase {

	/**
	 * 
	 */

	public WebDriver d;
	public ExtentReports extent=ExtentManager.getInstance();
	public ExtentTest logger;

	//Open Browser, initialize driver object and launch url
	public void init(String bType){
		if(bType.equals("Firefox")){
			try{
				System.setProperty("webdriver.gecko.driver", Constants.FIREFOX_DRIVER_EXE);
				d= new FirefoxDriver();
			} catch (Exception e){
				e.printStackTrace();
				Assert.fail("Error opening Browser");
			}
		}
		else if (bType.equals("IE")) {
			try {
				System.setProperty("webdriver.ie.driver", Constants.IE_DRIVER_EXE);
				InternetExplorerOptions options = new InternetExplorerOptions();
				options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, "true");
				options.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, "true");
				d= new InternetExplorerDriver(options);
			} catch (Exception e){
				e.printStackTrace();
				Assert.fail("Error opening Browser");
			}
		}
		else if(bType.equals("Chrome")){
			try {
				//This piece of code will be used to open browser incognito mode, so that even if your gmail is already logged in, it won't be an issue	
				DesiredCapabilities capabilities= DesiredCapabilities.chrome();
				ChromeOptions options=new ChromeOptions();
				options.addArguments("incognito");
				options.addArguments("--disable-notifications");

				capabilities.setCapability(ChromeOptions.CAPABILITY, options);

				System.setProperty("webdriver.chrome.driver",Constants.CHROME_DRIVER_EXE);
				d=new ChromeDriver(options);
			} catch (Exception e){
				System.out.println("Exception in Chrome Browser");
				e.printStackTrace();
				Assert.fail("Error opening Browser");
			}
		}
		else 
			System.out.println("Browser Name is invalid or not supported in the framework");

		d.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		d.manage().window().maximize();
		d.manage().timeouts().pageLoadTimeout(300, TimeUnit.SECONDS);
		System.out.println("Browser Opened - "+ bType);
	}

	//quit webdriver session
	public void terminate() {
		d.quit();
	}

	//close current browser
	public void close() {
		d.close();
	}

	public void log(String... text) {
		try {
			String logText="";
			for (String temp: text) {			
				logText+=temp;
			}
			logger.log(Status.INFO, logText);

			System.out.println(logText);
		} catch (Exception e){
			e.printStackTrace();
		}
	}

	// Element high lighter code
	public void highLightElement(WebDriver d, WebElement e) 
	{
		JavascriptExecutor js=(JavascriptExecutor)d; 
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", e);
		try {
			Thread.sleep(200);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", e); 
	}
	
	public void jsClick(WebElement el) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)d;
			jse.executeScript("arguments[0].click();", el);
			log("Element clicked");
		} catch (Exception e){
			System.out.println("=============================================================");
			log("Exception-jsClick(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}
	}

	// Scroll Up page by co-ordinates
	public void scrollUp() throws Exception{
		try {
			JavascriptExecutor jse = (JavascriptExecutor)d;
			jse.executeScript("window.scrollBy(0,-250)", "");
			log("Page scrolled up");
		} catch (Exception e){
			System.out.println("=============================================================");
			log("Exception-scrollUp(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}       
	}

	// Scroll Down page by co-ordinates
	public void scrollDown() throws Exception{
		try {
			JavascriptExecutor jse = (JavascriptExecutor)d;
			jse.executeScript("window.scrollBy(0,250)", "");
			log("Page scrolled down");   
		} catch (Exception e){
			System.out.println("=============================================================");
			log("Exception-scrollDown(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}

	// Scroll element to view
	public void scrollIntoView(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor)d;
			jse.executeScript("arguments[0].scrollIntoView(true);", element);
			log("Page scrolled down");
		} catch (Exception e){
			System.out.println("=============================================================");
			log("Exception-scrollIntoView(): "+e.getMessage());
			takeScreenShot();
			e.printStackTrace();
			System.out.println("=============================================================");
		}    
	}

	public void reportPass(String msg){
		logger.log(Status.PASS, msg);
		System.out.println("**PASS: "+msg);
	}

	public void reportFailure(String msg) {
		logger.log(Status.FAIL, msg);
		System.out.println("**FAIL: "+msg);
		takeScreenShot();		
	}

	public void reportHardFailure(String failureMessage) throws IOException{
		logger.log(Status.FAIL, failureMessage);
		takeScreenShot();
		Assert.fail(failureMessage);
	}

	// Take screenshot of page and save in screenshots folder
	public void takeScreenShot() {
		Date date=new Date();
		String screenshotFile=date.toString().replace(":", "_").replace(" ", "_")+".png";
		String filePath=Constants.REPORT_PATH+"screenshots\\"+screenshotFile;

		try {
			
			File scrFile = ((TakesScreenshot)d).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
		//logger.log(Status.INFO,logger.addScreenCapture(filePath));
		try {
			logger.info("Screenshot",MediaEntityBuilder.createScreenCaptureFromPath(filePath).build());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Take screenshot of page and save in screenshots folder
	public void takeScreenShot(String fileName) {
		Date date=new Date();
		String screenshotFile=fileName.split("\\.")[0]+date.toString().replace(":", "_").replace(" ", "_")+"."+fileName.split("\\.")[1];
		String filePath=Constants.REPORT_PATH+"screenshots\\"+screenshotFile;

		try {
			File scrFile = ((TakesScreenshot)d).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
		//logger.log(Status.INFO,logger.addScreenCapture(filePath));
		try {
			logger.info("Screenshot",MediaEntityBuilder.createScreenCaptureFromPath(filePath).build());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Code for Static wait
	public void wait(int timeToWaitInSec){
		try {
			Thread.sleep(timeToWaitInSec * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Read data from excel -> Start row from 1
	public String readData(String fileName, String sheetName, int rowIndex, int cellIndex) throws Exception {
		File location = new File(fileName);
		FileInputStream fis = new FileInputStream(location);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = wb.getSheet(sheetName);

		String data;
		try {
			data = sheet1.getRow(rowIndex).getCell(cellIndex).getStringCellValue();
		} catch (NullPointerException e) {
			data = "";
		}

		wb.close();

		return data;
	}

	// Write data to excel
	public void setData(String fileName, String sheetName, int rowIndex, int cellIndex, String data) throws Exception {
		File location = new File(fileName);
		FileInputStream fis = new FileInputStream(location);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = wb.getSheet(sheetName);
		if (sheet1.getRow(rowIndex) == null) {
			sheet1.createRow(rowIndex).createCell(cellIndex).setCellValue(data);
		} else {
			sheet1.getRow(rowIndex).createCell(cellIndex).setCellValue(data);
		}
		FileOutputStream fos = new FileOutputStream(location);
		wb.write(fos);
		wb.close();
	}

	// Get count of rows from excel
	public int getRowCount(String fileName, String sheetName) throws IOException {
		File location = new File(fileName);
		FileInputStream fis = new FileInputStream(location);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = wb.getSheet(sheetName);

		return sheet1.getLastRowNum()+1;
	}
}

package src.test.java.com.pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import src.main.java.com.testing.base.TestBase;

public class AllMovies_PageFactory_Page2 extends TestBase{
	@FindBy(xpath="(//*[text()='Advanced Movie Search'])[2]")
	WebElement header;
	
	@FindBy(id="search_query_top")
	public WebElement topSearch;
	
	@FindBy(xpath="//h1[@class='page-heading  product-listing']")
	public WebElement searchCheck;
	
	@FindBy(id="selectProductSort")
	public WebElement sortBy;
	
	@FindBy(xpath="//option[@value='price:asc']")
	public WebElement lowestFirst;
	
	@FindBy(xpath="//div[@id='center_column']/ul/li")
	public WebElement firstHover;
	
	@FindBy(xpath="//div[@id='center_column']/ul/li//a/span[text()='Add to cart']")
	public WebElement addToCartFirstLink;
	
	@FindBy(xpath="//span[contains(text(),'Proceed to checkout')]/parent::a")
	public WebElement checkoutLink;
	
	@FindBy(xpath="(//span[contains(text(),'Proceed to checkout')]/parent::a)[2]")
	public WebElement checkoutSecondLink;
	
	@FindBy(xpath="//span[contains(text(),'Proceed to checkout')]/parent::button")
	public WebElement checkoutButton;
	
	@FindBy(id="email")
	public WebElement emailField;
	
	@FindBy(id="passwd")
	public WebElement pswdField;
	
	@FindBy(id="SubmitLogin")
	public WebElement loginSubmit;
	
	@FindBy(xpath="//input[@id='cgv' and @type='checkbox']")
	public WebElement checkBoxTC;
	
	@FindBy(xpath="//a[contains(@title,'Pay by check')]")
	public WebElement payByCheck;
	
	@FindBy(xpath="//span[contains(text(),'I confirm my order')]/parent::button[@type='submit']")
	public WebElement confirmMyOrder;
	
	@FindBy(xpath="//*[@id='center_column']/p[1]")
	public WebElement confirmationMessage;
	
	public AllMovies_PageFactory_Page2(WebDriver d) {
		this.d = d;
		PageFactory.initElements(d, this);
	}
	
	public void enterBasicSearchCriteria(WebElement e,String entry)
	{
		e.clear();
		e.sendKeys(entry);
		e.sendKeys(Keys.ENTER);
	}

}
